﻿namespace Corielan_Vladimir_BoletinCalificaciones.zip_
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            grpDatos = new GroupBox();
            lblNombre = new Label();
            txtEstudiante = new TextBox();
            lblTanda = new Label();
            rdbMatutina = new RadioButton();
            rdbVespertina = new RadioButton();
            grpRegistro = new GroupBox();
            lblAsignatura = new Label();
            cmbAsignatura = new ComboBox();
            lblCalificaciones = new Label();
            lblP1 = new Label();
            lblP2 = new Label();
            lblP3 = new Label();
            lblP4 = new Label();
            txtP1 = new TextBox();
            txtP2 = new TextBox();
            txtP3 = new TextBox();
            txtP4 = new TextBox();
            chkAsistencia = new CheckBox();
            btnRegistrar = new Button();
            grpBoletin = new GroupBox();
            lstBoletin = new ListBox();
            grpResumen = new GroupBox();
            lblTxtPromedio = new Label();
            lblPromedioGeneral = new Label();
            lblTxtAprobadas = new Label();
            lblAprobadas = new Label();
            lblTxtRecuperacion = new Label();
            lblRecuperacion = new Label();
            lblTxtReprobadas = new Label();
            lblReprobadas = new Label();
            lblTxtSituacion = new Label();
            lblSituacion = new Label();
            btnResumen = new Button();
            btnLimpiar = new Button();
            btnSalir = new Button();
            grpDatos.SuspendLayout();
            grpRegistro.SuspendLayout();
            grpBoletin.SuspendLayout();
            grpResumen.SuspendLayout();
            SuspendLayout();
            // 
            // grpDatos
            // 
            grpDatos.Controls.Add(lblNombre);
            grpDatos.Controls.Add(txtEstudiante);
            grpDatos.Controls.Add(lblTanda);
            grpDatos.Controls.Add(rdbMatutina);
            grpDatos.Controls.Add(rdbVespertina);
            grpDatos.Location = new Point(22, 28);
            grpDatos.Name = "grpDatos";
            grpDatos.Size = new Size(500, 178);
            grpDatos.TabIndex = 0;
            grpDatos.TabStop = false;
            grpDatos.Text = "Datos del estudiante";
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Location = new Point(19, 38);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(67, 20);
            lblNombre.TabIndex = 0;
            lblNombre.Text = "Nombre:";
            // 
            // txtEstudiante
            // 
            txtEstudiante.Location = new Point(112, 35);
            txtEstudiante.Name = "txtEstudiante";
            txtEstudiante.PlaceholderText = "Ej.: María Pérez";
            txtEstudiante.Size = new Size(362, 27);
            txtEstudiante.TabIndex = 1;
            // 
            // lblTanda
            // 
            lblTanda.AutoSize = true;
            lblTanda.Location = new Point(19, 100);
            lblTanda.Name = "lblTanda";
            lblTanda.Size = new Size(51, 20);
            lblTanda.TabIndex = 2;
            lblTanda.Text = "Tanda:";
            // 
            // rdbMatutina
            // 
            rdbMatutina.AutoSize = true;
            rdbMatutina.Location = new Point(112, 98);
            rdbMatutina.Name = "rdbMatutina";
            rdbMatutina.Size = new Size(89, 24);
            rdbMatutina.TabIndex = 3;
            rdbMatutina.Text = "Matutina";
            rdbMatutina.UseVisualStyleBackColor = true;
            // 
            // rdbVespertina
            // 
            rdbVespertina.AutoSize = true;
            rdbVespertina.Location = new Point(250, 98);
            rdbVespertina.Name = "rdbVespertina";
            rdbVespertina.Size = new Size(99, 24);
            rdbVespertina.TabIndex = 4;
            rdbVespertina.Text = "Vespertina";
            rdbVespertina.UseVisualStyleBackColor = true;
            // 
            // grpRegistro
            // 
            grpRegistro.Controls.Add(lblAsignatura);
            grpRegistro.Controls.Add(cmbAsignatura);
            grpRegistro.Controls.Add(lblCalificaciones);
            grpRegistro.Controls.Add(lblP1);
            grpRegistro.Controls.Add(lblP2);
            grpRegistro.Controls.Add(lblP3);
            grpRegistro.Controls.Add(lblP4);
            grpRegistro.Controls.Add(txtP1);
            grpRegistro.Controls.Add(txtP2);
            grpRegistro.Controls.Add(txtP3);
            grpRegistro.Controls.Add(txtP4);
            grpRegistro.Controls.Add(chkAsistencia);
            grpRegistro.Controls.Add(btnRegistrar);
            grpRegistro.Location = new Point(22, 221);
            grpRegistro.Name = "grpRegistro";
            grpRegistro.Size = new Size(500, 375);
            grpRegistro.TabIndex = 1;
            grpRegistro.TabStop = false;
            grpRegistro.Text = "Registro de asignatura";
            // 
            // lblAsignatura
            // 
            lblAsignatura.AutoSize = true;
            lblAsignatura.Location = new Point(19, 38);
            lblAsignatura.Name = "lblAsignatura";
            lblAsignatura.Size = new Size(83, 20);
            lblAsignatura.TabIndex = 0;
            lblAsignatura.Text = "Asignatura:";
            // 
            // cmbAsignatura
            // 
            cmbAsignatura.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbAsignatura.FormattingEnabled = true;
            cmbAsignatura.Location = new Point(134, 35);
            cmbAsignatura.Name = "cmbAsignatura";
            cmbAsignatura.Size = new Size(341, 28);
            cmbAsignatura.TabIndex = 1;
            // 
            // lblCalificaciones
            // 
            lblCalificaciones.AutoSize = true;
            lblCalificaciones.Location = new Point(19, 100);
            lblCalificaciones.Name = "lblCalificaciones";
            lblCalificaciones.Size = new Size(279, 20);
            lblCalificaciones.TabIndex = 2;
            lblCalificaciones.Text = "Calificaciones por período (0 a 100):";
            // 
            // lblP1
            // 
            lblP1.AutoSize = false;
            lblP1.Location = new Point(18, 131);
            lblP1.Name = "lblP1";
            lblP1.Size = new Size(101, 20);
            lblP1.TabIndex = 3;
            lblP1.Text = "P1";
            lblP1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblP2
            // 
            lblP2.AutoSize = false;
            lblP2.Location = new Point(134, 131);
            lblP2.Name = "lblP2";
            lblP2.Size = new Size(101, 20);
            lblP2.TabIndex = 4;
            lblP2.Text = "P2";
            lblP2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblP3
            // 
            lblP3.AutoSize = false;
            lblP3.Location = new Point(251, 131);
            lblP3.Name = "lblP3";
            lblP3.Size = new Size(101, 20);
            lblP3.TabIndex = 5;
            lblP3.Text = "P3";
            lblP3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblP4
            // 
            lblP4.AutoSize = false;
            lblP4.Location = new Point(368, 131);
            lblP4.Name = "lblP4";
            lblP4.Size = new Size(101, 20);
            lblP4.TabIndex = 6;
            lblP4.Text = "P4";
            lblP4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // txtP1
            // 
            txtP1.Location = new Point(18, 158);
            txtP1.Name = "txtP1";
            txtP1.Size = new Size(101, 27);
            txtP1.TabIndex = 7;
            txtP1.TextAlign = HorizontalAlignment.Center;
            // 
            // txtP2
            // 
            txtP2.Location = new Point(134, 158);
            txtP2.Name = "txtP2";
            txtP2.Size = new Size(101, 27);
            txtP2.TabIndex = 8;
            txtP2.TextAlign = HorizontalAlignment.Center;
            // 
            // txtP3
            // 
            txtP3.Location = new Point(251, 158);
            txtP3.Name = "txtP3";
            txtP3.Size = new Size(101, 27);
            txtP3.TabIndex = 9;
            txtP3.TextAlign = HorizontalAlignment.Center;
            // 
            // txtP4
            // 
            txtP4.Location = new Point(368, 158);
            txtP4.Name = "txtP4";
            txtP4.Size = new Size(101, 27);
            txtP4.TabIndex = 10;
            txtP4.TextAlign = HorizontalAlignment.Center;
            // 
            // chkAsistencia
            // 
            chkAsistencia.AutoSize = true;
            chkAsistencia.Checked = true;
            chkAsistencia.CheckState = CheckState.Checked;
            chkAsistencia.Location = new Point(19, 235);
            chkAsistencia.Name = "chkAsistencia";
            chkAsistencia.Size = new Size(277, 24);
            chkAsistencia.TabIndex = 11;
            chkAsistencia.Text = "Cumple la asistencia mínima (80 %)";
            chkAsistencia.UseVisualStyleBackColor = true;
            // 
            // btnRegistrar
            // 
            btnRegistrar.Location = new Point(18, 294);
            btnRegistrar.Name = "btnRegistrar";
            btnRegistrar.Size = new Size(458, 40);
            btnRegistrar.TabIndex = 12;
            btnRegistrar.Text = "Registrar asignatura";
            btnRegistrar.UseVisualStyleBackColor = true;
            btnRegistrar.Click += btnRegistrar_Click;
            // 
            // grpBoletin
            // 
            grpBoletin.Controls.Add(lstBoletin);
            grpBoletin.Location = new Point(548, 28);
            grpBoletin.Name = "grpBoletin";
            grpBoletin.Size = new Size(418, 282);
            grpBoletin.TabIndex = 2;
            grpBoletin.TabStop = false;
            grpBoletin.Text = "Boletín del estudiante";
            // 
            // lstBoletin
            // 
            lstBoletin.FormattingEnabled = true;
            lstBoletin.Location = new Point(19, 28);
            lstBoletin.Name = "lstBoletin";
            lstBoletin.Size = new Size(372, 224);
            lstBoletin.TabIndex = 0;
            // 
            // grpResumen
            // 
            grpResumen.Controls.Add(lblTxtPromedio);
            grpResumen.Controls.Add(lblPromedioGeneral);
            grpResumen.Controls.Add(lblTxtAprobadas);
            grpResumen.Controls.Add(lblAprobadas);
            grpResumen.Controls.Add(lblTxtRecuperacion);
            grpResumen.Controls.Add(lblRecuperacion);
            grpResumen.Controls.Add(lblTxtReprobadas);
            grpResumen.Controls.Add(lblReprobadas);
            grpResumen.Controls.Add(lblTxtSituacion);
            grpResumen.Controls.Add(lblSituacion);
            grpResumen.Location = new Point(548, 332);
            grpResumen.Name = "grpResumen";
            grpResumen.Size = new Size(418, 264);
            grpResumen.TabIndex = 3;
            grpResumen.TabStop = false;
            grpResumen.Text = "Resumen";
            // 
            // lblTxtPromedio
            // 
            lblTxtPromedio.AutoSize = true;
            lblTxtPromedio.Location = new Point(19, 36);
            lblTxtPromedio.Name = "lblTxtPromedio";
            lblTxtPromedio.Size = new Size(132, 20);
            lblTxtPromedio.TabIndex = 0;
            lblTxtPromedio.Text = "Promedio general:";
            // 
            // lblPromedioGeneral
            // 
            lblPromedioGeneral.AutoSize = false;
            lblPromedioGeneral.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lblPromedioGeneral.Location = new Point(316, 36);
            lblPromedioGeneral.Name = "lblPromedioGeneral";
            lblPromedioGeneral.Size = new Size(75, 20);
            lblPromedioGeneral.TabIndex = 1;
            lblPromedioGeneral.Text = "0.00";
            lblPromedioGeneral.TextAlign = ContentAlignment.TopRight;
            // 
            // lblTxtAprobadas
            // 
            lblTxtAprobadas.AutoSize = true;
            lblTxtAprobadas.Location = new Point(19, 72);
            lblTxtAprobadas.Name = "lblTxtAprobadas";
            lblTxtAprobadas.Size = new Size(85, 20);
            lblTxtAprobadas.TabIndex = 2;
            lblTxtAprobadas.Text = "Aprobadas:";
            // 
            // lblAprobadas
            // 
            lblAprobadas.AutoSize = false;
            lblAprobadas.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lblAprobadas.Location = new Point(316, 72);
            lblAprobadas.Name = "lblAprobadas";
            lblAprobadas.Size = new Size(75, 20);
            lblAprobadas.TabIndex = 3;
            lblAprobadas.Text = "0";
            lblAprobadas.TextAlign = ContentAlignment.TopRight;
            // 
            // lblTxtRecuperacion
            // 
            lblTxtRecuperacion.AutoSize = true;
            lblTxtRecuperacion.Location = new Point(19, 108);
            lblTxtRecuperacion.Name = "lblTxtRecuperacion";
            lblTxtRecuperacion.Size = new Size(124, 20);
            lblTxtRecuperacion.TabIndex = 4;
            lblTxtRecuperacion.Text = "En recuperación:";
            // 
            // lblRecuperacion
            // 
            lblRecuperacion.AutoSize = false;
            lblRecuperacion.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lblRecuperacion.Location = new Point(316, 108);
            lblRecuperacion.Name = "lblRecuperacion";
            lblRecuperacion.Size = new Size(75, 20);
            lblRecuperacion.TabIndex = 5;
            lblRecuperacion.Text = "0";
            lblRecuperacion.TextAlign = ContentAlignment.TopRight;
            // 
            // lblTxtReprobadas
            // 
            lblTxtReprobadas.AutoSize = true;
            lblTxtReprobadas.Location = new Point(19, 144);
            lblTxtReprobadas.Name = "lblTxtReprobadas";
            lblTxtReprobadas.Size = new Size(92, 20);
            lblTxtReprobadas.TabIndex = 6;
            lblTxtReprobadas.Text = "Reprobadas:";
            // 
            // lblReprobadas
            // 
            lblReprobadas.AutoSize = false;
            lblReprobadas.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lblReprobadas.Location = new Point(316, 144);
            lblReprobadas.Name = "lblReprobadas";
            lblReprobadas.Size = new Size(75, 20);
            lblReprobadas.TabIndex = 7;
            lblReprobadas.Text = "0";
            lblReprobadas.TextAlign = ContentAlignment.TopRight;
            // 
            // lblTxtSituacion
            // 
            lblTxtSituacion.AutoSize = true;
            lblTxtSituacion.Location = new Point(19, 190);
            lblTxtSituacion.Name = "lblTxtSituacion";
            lblTxtSituacion.Size = new Size(76, 20);
            lblTxtSituacion.TabIndex = 8;
            lblTxtSituacion.Text = "Situación:";
            // 
            // lblSituacion
            // 
            lblSituacion.AutoSize = false;
            lblSituacion.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lblSituacion.Location = new Point(101, 190);
            lblSituacion.Name = "lblSituacion";
            lblSituacion.Size = new Size(295, 24);
            lblSituacion.TabIndex = 9;
            lblSituacion.Text = "---";
            // 
            // btnResumen
            // 
            btnResumen.Location = new Point(22, 620);
            btnResumen.Name = "btnResumen";
            btnResumen.Size = new Size(278, 44);
            btnResumen.TabIndex = 4;
            btnResumen.Text = "Mostrar resumen";
            btnResumen.UseVisualStyleBackColor = true;
            btnResumen.Click += btnResumen_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Location = new Point(355, 620);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(278, 44);
            btnLimpiar.TabIndex = 5;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // btnSalir
            // 
            btnSalir.Location = new Point(688, 620);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(278, 44);
            btnSalir.TabIndex = 6;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            // 
            // Form1
            // 
            AcceptButton = btnRegistrar;
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(990, 690);
            Controls.Add(grpDatos);
            Controls.Add(grpRegistro);
            Controls.Add(grpBoletin);
            Controls.Add(grpResumen);
            Controls.Add(btnResumen);
            Controls.Add(btnLimpiar);
            Controls.Add(btnSalir);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Boletín de Calificaciones";
            Load += Form1_Load;
            grpDatos.ResumeLayout(false);
            grpDatos.PerformLayout();
            grpRegistro.ResumeLayout(false);
            grpRegistro.PerformLayout();
            grpBoletin.ResumeLayout(false);
            grpResumen.ResumeLayout(false);
            grpResumen.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox grpDatos;
        private Label lblNombre;
        private TextBox txtEstudiante;
        private Label lblTanda;
        private RadioButton rdbMatutina;
        private RadioButton rdbVespertina;
        private GroupBox grpRegistro;
        private Label lblAsignatura;
        private ComboBox cmbAsignatura;
        private Label lblCalificaciones;
        private Label lblP1;
        private Label lblP2;
        private Label lblP3;
        private Label lblP4;
        private TextBox txtP1;
        private TextBox txtP2;
        private TextBox txtP3;
        private TextBox txtP4;
        private CheckBox chkAsistencia;
        private Button btnRegistrar;
        private GroupBox grpBoletin;
        private ListBox lstBoletin;
        private GroupBox grpResumen;
        private Label lblTxtPromedio;
        private Label lblPromedioGeneral;
        private Label lblTxtAprobadas;
        private Label lblAprobadas;
        private Label lblTxtRecuperacion;
        private Label lblRecuperacion;
        private Label lblTxtReprobadas;
        private Label lblReprobadas;
        private Label lblTxtSituacion;
        private Label lblSituacion;
        private Button btnResumen;
        private Button btnLimpiar;
        private Button btnSalir;
    }
}