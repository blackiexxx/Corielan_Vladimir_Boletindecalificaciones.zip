using System;
using System.Windows.Forms;

namespace Corielan_Vladimir_BoletinCalificaciones.zip_
{
    public partial class Form1 : Form
    {    
        // Valores que no cambian
        const double NOTA_APROBADA = 70;      // con 70 o más se aprueba
        const double NOTA_RECUPERACION = 60;  // de 60 a 69.99 va a recuperación
        const int PERIODOS = 4;               // cuántas notas tiene cada materia
        const double NOTA_MINIMA = 0;
        const double NOTA_MAXIMA = 100;

        // Aquí voy guardando lo que se registra
        double sumaPromedios = 0;   // suma de todos los promedios
        int totalAsignaturas = 0;   // cuántas materias llevo
        int aprobadas = 0;
        int recuperacion = 0;
        int reprobadas = 0;

        public Form1()
        {
            InitializeComponent();
        }

        // Al abrir el formulario: lleno el combo y lo dejo limpio
        private void Form1_Load(object sender, EventArgs e)
        {
            cmbAsignatura.Items.Clear();
            cmbAsignatura.Items.Add("Matemática");
            cmbAsignatura.Items.Add("Lengua Española");
            cmbAsignatura.Items.Add("Ciencias Naturales");
            cmbAsignatura.Items.Add("Inglés");
            cmbAsignatura.Items.Add("Informática");

            LimpiarFormulario();
        }

        // Botón Registrar: revisa los datos, calcula y agrega la materia a la lista
        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            // Primero reviso que no falte nada
            if (string.IsNullOrWhiteSpace(txtEstudiante.Text))
            {
                MessageBox.Show("Escriba el nombre del estudiante.", "Dato faltante",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtEstudiante.Focus();
                return;
            }

            if (!rdbMatutina.Checked && !rdbVespertina.Checked)
            {
                MessageBox.Show("Seleccione la tanda del estudiante.", "Dato faltante",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cmbAsignatura.SelectedIndex == -1)
            {
                MessageBox.Show("Seleccione una asignatura.", "Dato faltante",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbAsignatura.Focus();
                return;
            }

            // Leo las 4 notas (si alguna está mal, me salgo)
            double p1, p2, p3, p4;
            if (!LeerNota(txtP1, "P1", out p1)) return;
            if (!LeerNota(txtP2, "P2", out p2)) return;
            if (!LeerNota(txtP3, "P3", out p3)) return;
            if (!LeerNota(txtP4, "P4", out p4)) return;

            // Saco el promedio
            double promedio = (p1 + p2 + p3 + p4) / PERIODOS;

            // Veo cómo quedó la materia
            string situacion;
            if (!chkAsistencia.Checked)
            {
                // Sin asistencia se reprueba, sin importar la nota
                situacion = "Reprobada por asistencia";
                reprobadas++;
            }
            else if (promedio >= NOTA_APROBADA)
            {
                situacion = "Aprobada";
                aprobadas++;
            }
            else if (promedio >= NOTA_RECUPERACION)
            {
                situacion = "En recuperación";
                recuperacion++;
            }
            else
            {
                situacion = "Reprobada";
                reprobadas++;
            }

            // Guardo los datos y la muestro en la lista
            sumaPromedios += promedio;
            totalAsignaturas++;
            lstBoletin.Items.Add(cmbAsignatura.Text + " · " + promedio.ToString("F2") + " · " + situacion);

            // Dejo todo listo para la siguiente materia
            cmbAsignatura.SelectedIndex = -1;
            txtP1.Clear();
            txtP2.Clear();
            txtP3.Clear();
            txtP4.Clear();
            chkAsistencia.Checked = true;
            cmbAsignatura.Focus();
        }

        // Botón Mostrar resumen: enseña el promedio general y los conteos
        private void btnResumen_Click(object sender, EventArgs e)
        {
            // Si no hay materias, no hay nada que resumir
            if (totalAsignaturas == 0)
            {
                MessageBox.Show("Registre al menos una asignatura antes de mostrar el resumen.",
                    "Sin asignaturas", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Promedio de los promedios
            double promedioGeneral = sumaPromedios / totalAsignaturas;

            lblPromedioGeneral.Text = promedioGeneral.ToString("F2");
            lblAprobadas.Text = aprobadas.ToString();
            lblRecuperacion.Text = recuperacion.ToString();
            lblReprobadas.Text = reprobadas.ToString();

            // La situación general depende de lo peor que haya
            if (reprobadas > 0)
            {
                lblSituacion.Text = "Tiene asignaturas reprobadas";
            }
            else if (recuperacion > 0)
            {
                lblSituacion.Text = "Tiene asignaturas en recuperación";
            }
            else
            {
                lblSituacion.Text = "Aprobó todas las asignaturas";
            }
        }

        // Botón Limpiar: deja el formulario como al empezar
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarFormulario();
        }

        // Botón Salir: cierra el programa
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }

        

        // Lee una nota y comprueba que sea un número entre 0 y 100
        private bool LeerNota(TextBox caja, string periodo, out double nota)
        {
            if (!double.TryParse(caja.Text, out nota))
            {
                MessageBox.Show("La calificación de " + periodo + " debe ser un número.",
                    "Dato inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                caja.Focus();
                return false;
            }

            if (nota < NOTA_MINIMA || nota > NOTA_MAXIMA)
            {
                MessageBox.Show("La calificación de " + periodo + " debe estar entre " +
                    NOTA_MINIMA + " y " + NOTA_MAXIMA + ".",
                    "Dato inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                caja.Focus();
                return false;
            }

            return true;
        }

        // Borra todo y pone los contadores en cero
        private void LimpiarFormulario()
        {
            txtEstudiante.Clear();
            rdbMatutina.Checked = false;
            rdbVespertina.Checked = false;
            cmbAsignatura.SelectedIndex = -1;
            txtP1.Clear();
            txtP2.Clear();
            txtP3.Clear();
            txtP4.Clear();
            chkAsistencia.Checked = true;
            lstBoletin.Items.Clear();

            sumaPromedios = 0;
            totalAsignaturas = 0;
            aprobadas = 0;
            recuperacion = 0;
            reprobadas = 0;

            lblPromedioGeneral.Text = "0.00";
            lblAprobadas.Text = "0";
            lblRecuperacion.Text = "0";
            lblReprobadas.Text = "0";
            lblSituacion.Text = "---";

            txtEstudiante.Focus();
        }
    }
}